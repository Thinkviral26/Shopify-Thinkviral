import detail from "@/assets/detail.jpg";
import caseShot from "@/assets/case.jpg";
import heroUser from "@/assets/earbuds-hero-user.png.asset.json";
import lifestyleHero from "@/assets/lifestyle-hero.png.asset.json";
import productSceneWhite from "@/assets/product-earbuds-scene-white.png.asset.json";
import productOpenCase from "@/assets/product-earbuds-open-case.png.asset.json";
import productBlack from "@/assets/product-earbuds-black.png.asset.json";
import productFloating from "@/assets/product-earbuds-floating.png.asset.json";
import productCover from "@/assets/product-earbuds-cover.png.asset.json";

/**
 * Single source of truth for product information.
 * Replace values here — no product data is hard-coded in components.
 */
export type ProductColor = { name: string; swatch: string };

export const product = {
  id: "tv-001-earbuds",
  code: "TV / 001",
  name: "Stylish TWS Wireless Earbuds with Silicone Case Cover",
  titleLines: ["TWS WIRELESS", "EARBUDS + CASE"],
  description:
    "True wireless earbuds with touch sensor, HD mic and active noise cancellation. Bluetooth v5.1, 10 m range, 3 hours of play time and a silicone case cover included — works with Android and iOS.",
  price: 999,
  compareAtPrice: 1499,
  currency: "INR",
  badge: "LAUNCH",
  rating: 5,
  specs: [
    { label: "Type", value: "TWS (True Wireless)" },
    { label: "Bluetooth", value: "v5.1 · 10 m range" },
    { label: "Play time", value: "3 hours" },
    { label: "Charge time", value: "1 hour" },
    { label: "Noise cancellation", value: "Active (ANC)" },
    { label: "Mic", value: "HD mic · Touch sensor" },
    { label: "Compatibility", value: "Android & iOS" },
    { label: "Material", value: "ABS plastic" },
    { label: "Charging type", value: "iOS" },
    { label: "Frequency", value: "100 Hz" },
    { label: "In the box", value: "Earbuds + case cover (1 unit)" },
    { label: "Warranty", value: "1 month" },
    { label: "Country of origin", value: "India" },
  ],
  colors: [
    { name: "Black", swatch: "#050505" },
    { name: "White", swatch: "#F5F5F2" },
  ] as ProductColor[],
  images: [
    { src: productSceneWhite.url, alt: "White wireless earbuds and charging case on black stone" },
    { src: productOpenCase.url, alt: "White wireless earbuds in an open charging case" },
    { src: productBlack.url, alt: "Black wireless earbuds floating above their charging case" },
    { src: productFloating.url, alt: "White wireless earbuds floating above an open case" },
    { src: productCover.url, alt: "White wireless earbuds in a black silicone case cover" },
  ],
  heroImage: heroUser.url,
  lifestyleImage: lifestyleHero.url,
  detailImage: detail,
  caseImage: caseShot,
} as const;

export const formatPrice = (amount: number) =>
  new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: product.currency,
    maximumFractionDigits: 0,
  }).format(amount);
