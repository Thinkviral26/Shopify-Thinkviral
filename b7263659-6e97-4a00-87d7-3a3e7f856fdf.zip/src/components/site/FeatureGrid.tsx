import { Battery, Bluetooth, CircleDot, Package } from "lucide-react";
import { Reveal } from "./Reveal";

const features = [
  {
    num: "01",
    title: "Wireless",
    copy: "No cable clutter. Pair, play and move.",
    icon: Bluetooth,
  },
  {
    num: "02",
    title: "Compact",
    copy: "Pocket-sized case designed for daily carry.",
    icon: Package,
  },
  {
    num: "03",
    title: "Everyday",
    copy: "Made around music, calls, commutes and focus.",
    icon: Battery,
  },
  {
    num: "04",
    title: "Think Different.",
    copy: "Useful technology without unnecessary complexity.",
    icon: CircleDot,
  },
];

export function FeatureGrid() {
  return (
    <section id="features" className="bg-paper py-20 md:py-32">
      <div className="mx-auto max-w-[1600px] px-5 md:px-10">
        <Reveal>
          <p className="label-mono text-grey">Features / 003</p>
          <h2 className="display mt-6 max-w-4xl text-[11vw] text-ink sm:text-[8vw] lg:text-[5.4vw]">
            <span className="block">Tech that</span>
            <span className="block">Gets out of the way.</span>
          </h2>
        </Reveal>

        <div className="relative mt-14 md:mt-20">
          <div
            aria-hidden
            className="pointer-events-none absolute -inset-10 opacity-70"
            style={{
              background:
                "radial-gradient(40% 45% at 20% 30%, color-mix(in oklab, var(--rgb-blue) 12%, transparent), transparent 70%), radial-gradient(35% 40% at 80% 70%, color-mix(in oklab, var(--rgb-violet) 10%, transparent), transparent 70%)",
              filter: "blur(50px)",
            }}
          />
          <div className="relative grid gap-4 md:grid-cols-2 xl:grid-cols-4">
          {features.map((f, i) => (
            <Reveal
              key={f.num}
              delay={i * 90}
              className="group glass-light glass-light-hover relative p-8 md:p-10"
            >
              <span
                aria-hidden
                className="pointer-events-none absolute inset-0 opacity-0 transition-opacity duration-500 group-hover:opacity-100"
                style={{
                  background:
                    "radial-gradient(70% 60% at 50% 100%, color-mix(in oklab, var(--rgb-blue) 14%, transparent), transparent 70%)",
                }}
              />
              <div className="relative flex min-h-[280px] flex-col justify-between md:min-h-[340px]">
                <div className="flex items-start justify-between">
                  <span className="label-mono text-grey">{f.num}</span>
                  <f.icon
                    className="size-5 text-ink transition-transform duration-500 group-hover:-translate-y-1 group-hover:text-rgb-blue"
                    strokeWidth={1.25}
                  />
                </div>
                <div>
                  <h3 className="display text-3xl text-ink md:text-4xl">{f.title}</h3>
                  <p className="mt-4 max-w-[26ch] text-sm leading-relaxed text-grey">{f.copy}</p>
                </div>
              </div>
            </Reveal>
          ))}
          </div>
        </div>
      </div>
    </section>
  );
}
