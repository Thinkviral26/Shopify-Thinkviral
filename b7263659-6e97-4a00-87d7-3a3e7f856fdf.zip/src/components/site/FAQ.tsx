import { useState } from "react";
import { Plus } from "lucide-react";
import { cn } from "@/lib/utils";
import { Reveal } from "./Reveal";

const faqs = [
  {
    q: "Are these original Apple AirPods?",
    a: "No. These are independently branded wireless earbuds and are not affiliated with Apple.",
  },
  {
    q: "Will they work with iPhone and Android?",
    a: "Yes. They connect over standard Bluetooth pairing, so they work with both iPhone and Android devices.",
  },
  {
    q: "How long does shipping take?",
    a: "Delivery timing is shown at checkout based on your pin code.",
  },
  {
    q: "Do you offer Cash on Delivery?",
    a: "Available payment options, including Cash on Delivery where supported, are shown at checkout.",
  },
  {
    q: "What is your return/replacement policy?",
    a: "Reach out to our support team with your order details and we'll guide you through the return or replacement process.",
  },
  {
    q: "How can I contact support?",
    a: "Email us and our team will help with orders, delivery and product questions.",
  },
];

export function FAQ() {
  const [open, setOpen] = useState<number | null>(0);

  return (
    <section id="faq" className="bg-paper py-20 md:py-32">
      <div className="mx-auto grid max-w-[1600px] gap-12 px-5 md:px-10 lg:grid-cols-[0.8fr_1.2fr] lg:gap-20">
        <Reveal>
          <p className="label-mono text-grey">FAQ</p>
          <h2 className="display mt-6 text-[11vw] text-ink sm:text-[8vw] lg:text-[4.4vw]">
            <span className="block">Common</span>
            <span className="block">Questions.</span>
          </h2>
        </Reveal>

        <Reveal delay={120} className="flex flex-col gap-3">
          {faqs.map((faq, i) => {
            const isOpen = open === i;
            return (
              <div
                key={faq.q}
                className={cn(
                  "glass-light transition-all duration-400",
                  isOpen && "border-ink/25 shadow-[inset_0_1px_0_oklch(1_0_0/70%),0_24px_60px_-30px_color-mix(in_oklab,var(--rgb-blue)_30%,transparent)]",
                )}
              >
                <button
                  onClick={() => setOpen(isOpen ? null : i)}
                  aria-expanded={isOpen}
                  className="flex w-full items-center justify-between gap-6 px-5 py-6 text-left md:px-6"
                >
                  <span className="text-base font-semibold tracking-tight text-ink md:text-lg">
                    {faq.q}
                  </span>
                  <Plus
                    className={cn(
                      "size-4 shrink-0 text-ink transition-transform duration-400",
                      isOpen && "rotate-45",
                    )}
                    strokeWidth={1.5}
                  />
                </button>
                <div
                  className="grid transition-[grid-template-rows] duration-400 ease-out"
                  style={{ gridTemplateRows: isOpen ? "1fr" : "0fr" }}
                >
                  <div className="overflow-hidden">
                    <p className="max-w-xl px-5 pb-7 text-sm leading-relaxed text-grey md:px-6 md:text-base">
                      {faq.a}
                    </p>
                  </div>
                </div>
              </div>
            );
          })}
        </Reveal>
      </div>
    </section>
  );
}
