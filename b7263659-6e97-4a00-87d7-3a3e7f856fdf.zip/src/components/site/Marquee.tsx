const items = ["WIRELESS AUDIO", "THINKVIRAL", "EVERYDAY TECH"];

export function Marquee() {
  const row = [...items, ...items, ...items, ...items];

  return (
    <div className="overflow-hidden border-y border-hairline-dark bg-ink py-5">
      <div className="marquee-track flex w-max items-center gap-8">
        {[0, 1].map((dup) => (
          <div key={dup} className="flex items-center gap-8">
            {row.map((item, i) => (
              <span key={`${dup}-${i}`} className="label-mono flex items-center gap-8 text-paper/60">
                {item}
                <span className="text-rgb-blue">✦</span>
              </span>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
}
