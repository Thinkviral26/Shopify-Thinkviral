import { ArrowRight } from "lucide-react";
import { product } from "@/data/product";
import { MagneticButton } from "./MagneticButton";
import { Reveal } from "./Reveal";

export function LifestyleSection() {
  return (
    <section className="relative overflow-hidden bg-ink">
      <img
        src={product.lifestyleImage}
        alt="THINKVIRAL earbuds and charging case on wet volcanic rock under a glowing light ring"
        loading="lazy"
        width={1920}
        height={880}
        className="absolute inset-0 h-full w-full object-cover object-center"
      />
      <div className="absolute inset-0 bg-linear-to-t from-ink via-ink/70 to-ink/30" />

      <div className="relative mx-auto flex min-h-[85vh] max-w-[1600px] flex-col justify-end px-5 py-20 md:px-10 md:py-28">
        <Reveal>
          <p className="label-mono text-paper/60">Real life. Better sound.</p>
          <h2 className="display mt-6 text-[14vw] text-paper sm:text-[10vw] lg:text-[6.4vw]">
            <span className="block">Your day.</span>
            <span className="outline-light block">Your sound.</span>
          </h2>
          <div className="mt-10">
            <MagneticButton
              variant="solid-light"
              onClick={() =>
                document.querySelector("#shop")?.scrollIntoView({ behavior: "smooth" })
              }
            >
              Get Yours <ArrowRight className="size-4" strokeWidth={2} />
            </MagneticButton>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
