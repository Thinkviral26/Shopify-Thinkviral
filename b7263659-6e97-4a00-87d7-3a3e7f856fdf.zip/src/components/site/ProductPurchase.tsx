import { useState } from "react";
import { ChevronLeft, ChevronRight, Headphones, Minus, Plus, ShieldCheck, Truck } from "lucide-react";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { formatPrice, product } from "@/data/product";
import { useCart } from "@/lib/cart";
import { MagneticButton } from "./MagneticButton";
import { Reveal } from "./Reveal";

const infoBlocks = [
  { icon: Truck, title: "Fast Delivery", copy: "Delivery timing shown at checkout." },
  { icon: ShieldCheck, title: "Secure Payments", copy: "UPI · Cards · Wallets" },
  { icon: Headphones, title: "Support", copy: "Reach us for order help." },
];

export function ProductPurchase() {
  const [active, setActive] = useState(0);
  const [color, setColor] = useState<string>(product.colors[0]?.name ?? "Black");
  const [qty, setQty] = useState(1);
  const { add, open } = useCart();

  const addToCart = () => {
    add({
      name: product.name,
      color,
      price: product.price,
      qty,
      image: product.images[0].src,
    });
    toast("Added to cart.");
  };

  const buyNow = () => {
    addToCart();
    open();
  };

  const showPrevious = () => {
    setActive((current) => (current - 1 + product.images.length) % product.images.length);
  };

  const showNext = () => {
    setActive((current) => (current + 1) % product.images.length);
  };

  return (
    <section id="shop" className="border-y border-hairline bg-paper py-16 md:py-20">
      <div className="mx-auto grid max-w-[1600px] gap-10 px-5 md:px-10 lg:grid-cols-[minmax(0,1.08fr)_minmax(430px,0.92fr)] lg:items-start lg:gap-12">
        {/* Gallery */}
        <Reveal className="order-1 lg:sticky lg:top-24">
          <div className="relative overflow-hidden border border-hairline bg-ink">
            <div className="group relative aspect-square overflow-hidden">
              {product.images.map((img, i) => (
                <img
                  key={img.alt}
                  src={img.src}
                  alt={img.alt}
                  loading="lazy"
                  className={cn(
                    "absolute inset-0 h-full w-full object-cover transition-[opacity,transform] duration-700 ease-out",
                    i === active ? "scale-100 opacity-100" : "pointer-events-none scale-[1.025] opacity-0",
                  )}
                />
              ))}

              <div className="absolute inset-x-0 bottom-0 flex items-center justify-between bg-gradient-to-t from-ink/65 to-transparent px-4 pt-14 pb-4">
                <span className="label-mono text-paper">
                  {String(active + 1).padStart(2, "0")} / {String(product.images.length).padStart(2, "0")}
                </span>
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={showPrevious}
                    aria-label="Show previous product image"
                    className="glass-dark flex size-11 items-center justify-center text-paper transition-colors hover:border-paper/35"
                  >
                    <ChevronLeft className="size-4" strokeWidth={1.5} />
                  </button>
                  <button
                    type="button"
                    onClick={showNext}
                    aria-label="Show next product image"
                    className="glass-dark flex size-11 items-center justify-center text-paper transition-colors hover:border-paper/35"
                  >
                    <ChevronRight className="size-4" strokeWidth={1.5} />
                  </button>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-3 grid grid-cols-5 gap-2 md:gap-3">
            {product.images.map((img, i) => (
              <button
                type="button"
                key={img.alt}
                onClick={() => setActive(i)}
                aria-label={`View image ${i + 1}`}
                aria-pressed={i === active}
                className={cn(
                  "relative aspect-square overflow-hidden border bg-paper-soft transition-[border-color,opacity]",
                  i === active ? "border-ink opacity-100" : "border-hairline opacity-65 hover:border-grey hover:opacity-100",
                )}
              >
                <img
                  src={img.src}
                  alt=""
                  loading="lazy"
                  className="h-full w-full object-cover"
                />
                <span className="label-mono absolute bottom-1 left-1 bg-ink/70 px-1.5 py-0.5 text-[8px] text-paper">
                  {String(i + 1).padStart(2, "0")}
                </span>
              </button>
            ))}
          </div>
        </Reveal>

        {/* Info */}
        <Reveal delay={120} className="order-2 flex min-w-0 flex-col">
          <div className="flex items-center gap-4">
            <span className="label-mono border border-ink px-2.5 py-1 text-ink">{product.badge}</span>
            <span className="label-mono text-grey">{product.code}</span>
          </div>

          <h2 className="display mt-6 text-[10vw] text-ink sm:text-[7vw] lg:text-[3.35vw]">
            {product.titleLines.map((line) => (
              <span key={line} className="block">
                {line}
              </span>
            ))}
          </h2>


          <div className="mt-6 flex items-end gap-4">
            <span className="text-4xl font-extrabold tracking-tight text-ink">
              {formatPrice(product.price)}
            </span>
            <span className="mb-1 font-mono text-sm text-grey line-through">
              {formatPrice(product.compareAtPrice)}
            </span>
          </div>

          <p className="mt-5 max-w-md text-sm leading-relaxed text-grey">
            {product.description}
          </p>

          <div className="mt-8 grid gap-6 border-y border-hairline py-6 sm:grid-cols-2">
            <div>
              <p className="label-mono text-grey">Colour</p>
              <div className="mt-3 flex flex-wrap gap-2">
                {product.colors.map((c) => (
                  <button
                    type="button"
                    key={c.name}
                    onClick={() => setColor(c.name)}
                    aria-pressed={color === c.name}
                    className={cn(
                      "label-mono glass-light glass-light-hover flex min-h-11 items-center gap-2.5 px-4",
                      color === c.name ? "border-ink/60 text-ink" : "text-grey",
                    )}
                  >
                    <span
                      className="size-3 rounded-full ring-1 ring-ink/10"
                      style={{ backgroundColor: c.swatch }}
                    />
                    {c.name}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <p className="label-mono text-grey">Quantity</p>
              <div className="glass-light mt-3 inline-flex items-center">
                <button
                  type="button"
                  aria-label="Decrease quantity"
                  onClick={() => setQty((q) => Math.max(1, q - 1))}
                  className="flex size-11 items-center justify-center text-ink transition-colors hover:bg-paper-soft"
                >
                  <Minus className="size-4" strokeWidth={1.5} />
                </button>
                <span className="w-11 text-center font-mono text-sm text-ink">{qty}</span>
                <button
                  type="button"
                  aria-label="Increase quantity"
                  onClick={() => setQty((q) => Math.min(10, q + 1))}
                  className="flex size-11 items-center justify-center text-ink transition-colors hover:bg-paper-soft"
                >
                  <Plus className="size-4" strokeWidth={1.5} />
                </button>
              </div>
            </div>
          </div>

          <div className="mt-10 flex flex-col gap-3 sm:flex-row">
            <MagneticButton variant="solid-dark" className="flex-1" onClick={addToCart}>
              Add to Cart
            </MagneticButton>
            <MagneticButton variant="ghost-dark" className="flex-1" onClick={buyNow}>
              Buy Now
            </MagneticButton>
          </div>

          <div className="mt-8 grid gap-3 sm:grid-cols-3">
            {infoBlocks.map((b) => (
              <div key={b.title} className="glass-light glass-light-hover flex flex-col gap-2 p-4">
                <b.icon className="size-4 text-ink" strokeWidth={1.25} />
                <p className="label-mono text-ink">{b.title}</p>
                <p className="text-xs leading-relaxed text-grey">{b.copy}</p>
              </div>
            ))}
          </div>

          <div className="mt-8">
            <p className="label-mono text-grey">Specifications</p>
            <dl className="mt-3 grid gap-px border border-hairline bg-hairline sm:grid-cols-2">
              {product.specs.map((s) => (
                <div key={s.label} className="flex min-h-12 items-center justify-between gap-3 bg-paper px-3 py-2.5">
                  <dt className="label-mono text-grey">{s.label}</dt>
                  <dd className="text-right text-xs font-medium text-ink">{s.value}</dd>
                </div>
              ))}
              {product.specs.length % 2 !== 0 && (
                <div aria-hidden className="bg-paper px-4 py-3 max-sm:hidden" />
              )}
            </dl>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
