import { createElement, Suspense, useEffect, useMemo } from "react";
import { Canvas, useThree } from "@react-three/fiber";
import {
  ContactShadows,
  Environment,
  Lightformer,
  OrbitControls,
  useGLTF,
} from "@react-three/drei";
import { SkeletonUtils } from "three-stdlib";
import type { OrbitControls as OrbitControlsImpl } from "three-stdlib";
import * as THREE from "three";

import modelAsset from "@/assets/AirPods_Pro_3.glb.asset.json";
import { useReducedMotion } from "@/hooks/use-motion-prefs";

const TARGET = new THREE.Vector3(0, 0, 0);
// Model is normalized to its largest side = 2.85 units, so half-size is 1.425.
const MODEL_HALF_SIZE = 1.425;
const FIT_MARGIN = 1.18;

function ProductModel() {
  const { scene } = useGLTF(modelAsset.url);
  const model = useMemo(() => {
    const object = SkeletonUtils.clone(scene);
    const box = new THREE.Box3().setFromObject(object);
    const size = box.getSize(new THREE.Vector3());
    const largestSide = Math.max(size.x, size.y, size.z) || 1;
    object.scale.setScalar(2.85 / largestSide);

    const scaledBox = new THREE.Box3().setFromObject(object);
    const center = scaledBox.getCenter(new THREE.Vector3());
    object.position.sub(center);

    object.traverse((child) => {
      if (child instanceof THREE.Mesh) {
        child.castShadow = true;
        child.receiveShadow = true;
      }
    });

    return object;
  }, [scene]);

  // createElement prevents editor-only DOM metadata from being forwarded to Three.js objects.
  return createElement("primitive", { object: model, rotation: [0.08, -0.35, 0] });
}

function SceneLights() {
  return (
    <>
      {createElement("ambientLight", { intensity: 0.75 })}
      {createElement("directionalLight", {
        position: [4, 6, 5],
        intensity: 2.6,
        castShadow: true,
        "shadow-mapSize": [1024, 1024],
      })}
      {createElement("directionalLight", {
        position: [-4, 1, 3],
        intensity: 1.1,
        color: "#83b8ff",
      })}
      {createElement("pointLight", {
        position: [2, -1, 2],
        intensity: 1.3,
        color: "#b592ff",
      })}
    </>
  );
}

/**
 * Keeps the model at a constant, fully-visible size: the camera distance is
 * derived from the field of view and the canvas aspect ratio, so the earbuds
 * always fill the same fraction of the viewer on any screen size.
 */
function CameraFit() {
  const camera = useThree((state) => state.camera) as THREE.PerspectiveCamera;
  const size = useThree((state) => state.size);
  const controls = useThree((state) => state.controls) as OrbitControlsImpl | null;

  useEffect(() => {
    const vFov = THREE.MathUtils.degToRad(camera.fov);
    const aspect = size.width / size.height;
    const tanHalf = Math.tan(vFov / 2);
    const fitHeight = MODEL_HALF_SIZE / tanHalf;
    const fitWidth = MODEL_HALF_SIZE / (tanHalf * aspect);
    const dist = Math.max(fitHeight, fitWidth) * FIT_MARGIN;

    const dir = camera.position.clone().sub(TARGET);
    if (dir.lengthSq() < 1e-6) dir.set(0, 0.25, 1);
    dir.normalize().multiplyScalar(dist);
    camera.position.copy(TARGET).add(dir);
    camera.updateProjectionMatrix();

    if (controls) {
      controls.target.copy(TARGET);
      controls.minDistance = dist * 0.9;
      controls.maxDistance = dist * 1.45;
      controls.update();
    }
  }, [camera, size, controls]);

  return null;
}

export default function HeroModelViewer() {
  const reducedMotion = useReducedMotion();

  return (
    <div className="relative h-full w-full cursor-grab touch-none active:cursor-grabbing">
      <Canvas
        shadows
        dpr={[1, 1.75]}
        camera={{ position: [0, 1.3, 5.2], fov: 34, near: 0.1, far: 100 }}
        gl={{ antialias: true, alpha: true }}
        aria-label="Interactive 3D viewer for THINKVIRAL wireless earbuds"
      >
        <SceneLights />

        <Suspense fallback={null}>
          <ProductModel />
          <Environment resolution={128}>
            <Lightformer intensity={3} position={[0, 5, 3]} scale={[8, 8, 1]} />
            <Lightformer intensity={2} color="#a8c9ff" position={[-5, 1, 1]} rotation-y={Math.PI / 2} scale={[6, 3, 1]} />
            <Lightformer intensity={1.5} color="#d5bdff" position={[5, 0, 0]} rotation-y={-Math.PI / 2} scale={[5, 3, 1]} />
          </Environment>
          <ContactShadows position={[0, -1.6, 0]} opacity={0.45} scale={5} blur={2.5} far={4} />
        </Suspense>

        <OrbitControls
          makeDefault
          autoRotate={!reducedMotion}
          autoRotateSpeed={0.75}
          enableDamping
          dampingFactor={0.07}
          enablePan={false}
          minPolarAngle={Math.PI * 0.2}
          maxPolarAngle={Math.PI * 0.8}
        />
        <CameraFit />
      </Canvas>

    </div>
  );
}

useGLTF.preload(modelAsset.url);
