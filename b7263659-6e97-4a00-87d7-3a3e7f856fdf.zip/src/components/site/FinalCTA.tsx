import { ArrowRight } from "lucide-react";
import { MagneticButton } from "./MagneticButton";
import { Reveal } from "./Reveal";

export function FinalCTA() {
  return (
    <section className="relative flex min-h-screen items-center overflow-hidden bg-ink">
      <div className="grid-texture absolute inset-0" />
      <div className="ambient-rgb pointer-events-none absolute inset-x-[8%] top-1/4 h-1/2 opacity-40" />

      <div className="relative mx-auto w-full max-w-[1600px] px-5 py-24 md:px-10">
        <Reveal>
          <p className="label-mono text-grey">THINKVIRAL / 007</p>
          <h2 className="display mt-10 text-[15vw] text-paper sm:text-[11vw] lg:text-[7.6vw]">
            <span className="block">Ready to go</span>
            <span className="outline-light block">Wireless?</span>
          </h2>
          <div className="mt-14">
            <MagneticButton
              variant="solid-light"
              onClick={() => document.querySelector("#shop")?.scrollIntoView({ behavior: "smooth" })}
            >
              Shop THINKVIRAL <ArrowRight className="size-4" strokeWidth={2} />
            </MagneticButton>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
