import { useEffect } from "react";
import { Minus, Plus, X } from "lucide-react";
import { cn } from "@/lib/utils";
import { formatPrice } from "@/data/product";
import { useCart } from "@/lib/cart";
import { MagneticButton } from "./MagneticButton";

export function CartDrawer() {
  const { items, isOpen, close, setQty, remove, subtotal, count } = useCart();

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && close();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [close]);

  return (
    <div className={cn("fixed inset-0 z-60", !isOpen && "pointer-events-none")}>
      <div
        onClick={close}
        className={cn(
          "absolute inset-0 bg-ink/70 backdrop-blur-sm transition-opacity duration-500",
          isOpen ? "opacity-100" : "opacity-0",
        )}
      />

      <aside
        className={cn(
          "absolute top-0 right-0 flex h-full w-full max-w-md flex-col border-l border-white/10 bg-ink/60 text-paper shadow-[inset_0_1px_0_oklch(1_0_0/8%),-30px_0_80px_-40px_oklch(0_0_0/80%)] backdrop-blur-2xl backdrop-saturate-150 transition-transform duration-500 ease-[cubic-bezier(0.22,1,0.36,1)]",
          isOpen ? "translate-x-0" : "translate-x-full",
        )}
      >
        <div className="flex items-center justify-between border-b border-hairline-dark px-6 py-5">
          <p className="label-mono">Cart ({count})</p>
          <button
            aria-label="Close cart"
            onClick={close}
            className="flex size-10 items-center justify-center text-paper/70 transition-colors hover:text-paper"
          >
            <X className="size-4" strokeWidth={1.5} />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto px-6">
          {items.length === 0 ? (
            <p className="label-mono py-16 text-grey">Your cart is empty.</p>
          ) : (
            items.map((item) => (
              <div key={item.key} className="flex gap-4 border-b border-hairline-dark py-6">
                <div className="size-20 shrink-0 border border-white/10 bg-white/5 backdrop-blur-md">
                  <img src={item.image} alt="" loading="lazy" className="h-full w-full object-contain p-1.5" />
                </div>
                <div className="flex-1">
                  <p className="text-sm font-semibold tracking-tight">{item.name}</p>
                  <p className="label-mono mt-1 text-grey">{item.color}</p>
                  <div className="mt-3 flex items-center justify-between">
                    <div className="inline-flex items-center border border-hairline-dark">
                      <button
                        aria-label="Decrease quantity"
                        onClick={() => setQty(item.key, item.qty - 1)}
                        className="flex size-9 items-center justify-center text-paper/70 hover:text-paper"
                      >
                        <Minus className="size-3.5" strokeWidth={1.5} />
                      </button>
                      <span className="w-8 text-center font-mono text-xs">{item.qty}</span>
                      <button
                        aria-label="Increase quantity"
                        onClick={() => setQty(item.key, item.qty + 1)}
                        className="flex size-9 items-center justify-center text-paper/70 hover:text-paper"
                      >
                        <Plus className="size-3.5" strokeWidth={1.5} />
                      </button>
                    </div>
                    <span className="font-mono text-sm">{formatPrice(item.price * item.qty)}</span>
                  </div>
                  <button
                    onClick={() => remove(item.key)}
                    className="label-mono mt-3 text-grey underline-offset-4 transition-colors hover:text-paper hover:underline"
                  >
                    Remove
                  </button>
                </div>
              </div>
            ))
          )}
        </div>

        <div className="border-t border-hairline-dark px-6 py-6">
          <div className="flex items-center justify-between">
            <span className="label-mono text-grey">Subtotal</span>
            <span className="text-xl font-extrabold tracking-tight">{formatPrice(subtotal)}</span>
          </div>
          <MagneticButton
            variant="solid-light"
            className="mt-5 w-full"
            disabled={items.length === 0}
            onClick={close}
          >
            Checkout
          </MagneticButton>
          <p className="label-mono mt-4 text-center text-grey">UPI · Cards · Wallets</p>
        </div>
      </aside>
    </div>
  );
}
