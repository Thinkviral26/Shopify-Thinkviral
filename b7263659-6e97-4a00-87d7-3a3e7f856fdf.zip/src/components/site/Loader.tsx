import { useEffect, useState } from "react";
import { cn } from "@/lib/utils";
import { Wordmark } from "./Wordmark";

/** Black intro screen: wordmark, thin progress line, counter, then fades away. */
export function Loader() {
  const [progress, setProgress] = useState(0);
  const [done, setDone] = useState(false);

  useEffect(() => {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      setDone(true);
      return;
    }
    let value = 0;
    const tick = window.setInterval(() => {
      value = Math.min(100, value + Math.random() * 18 + 6);
      setProgress(Math.round(value));
      if (value >= 100) {
        window.clearInterval(tick);
        window.setTimeout(() => setDone(true), 320);
      }
    }, 110);
    return () => window.clearInterval(tick);
  }, []);

  useEffect(() => {
    document.body.style.overflow = done ? "" : "hidden";
    return () => {
      document.body.style.overflow = "";
    };
  }, [done]);

  return (
    <div
      aria-hidden
      className={cn(
        "fixed inset-0 z-[100] flex flex-col items-center justify-center bg-ink transition-opacity duration-700",
        done ? "pointer-events-none opacity-0" : "opacity-100",
      )}
    >
      <Wordmark className="w-[56vw] max-w-xl" />
      <div className="mt-8 h-px w-[42vw] max-w-md bg-paper/15">
        <div
          className="h-px bg-paper transition-[width] duration-200 ease-out"
          style={{ width: `${progress}%` }}
        />
      </div>
      <span className="label-mono mt-4 text-grey">{String(progress).padStart(3, "0")}</span>
    </div>
  );
}
