import { createElement, useEffect, useRef, useState, type CSSProperties, type ElementType, type ReactNode } from "react";
import { cn } from "@/lib/utils";

type RevealProps = {
  children: ReactNode;
  className?: string;
  delay?: number;
  as?: ElementType;
  variant?: "fade" | "clip";
};

/** Scroll-triggered reveal: opacity + translateY + slight blur (or a clip-path wipe). */
export function Reveal({ children, className, delay = 0, as, variant = "fade" }: RevealProps) {
  const Tag = (as ?? "div") as ElementType;
  const ref = useRef<HTMLElement | null>(null);
  const [shown, setShown] = useState(false);

  useEffect(() => {
    const node = ref.current;
    if (!node) return;

    const inView = () => {
      const r = node.getBoundingClientRect();
      return r.top < window.innerHeight * 0.92 && r.bottom > 0;
    };

    if (inView()) {
      setShown(true);
      return;
    }

    const io = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting || inView()) {
            setShown(true);
            io.disconnect();
          }
        }
      },
      { rootMargin: "0px 0px -8% 0px", threshold: 0 },
    );
    io.observe(node);

    const onScroll = () => {
      if (inView()) {
        setShown(true);
        io.disconnect();
        window.removeEventListener("scroll", onScroll);
      }
    };
    window.addEventListener("scroll", onScroll, { passive: true });

    return () => {
      io.disconnect();
      window.removeEventListener("scroll", onScroll);
    };
  }, []);

  const isClip = variant === "clip";

  const style: CSSProperties = {
    ...(delay ? { transitionDelay: `${delay}ms` } : null),
    ...(isClip ? { clipPath: shown ? "inset(0 0 0 0)" : "inset(0 0 100% 0)" } : null),
  };

  return createElement(
    Tag,
    {
      ref,
      style,
      className: cn(isClip ? "clip-reveal" : "reveal", !isClip && shown && "reveal-in", className),
    },
    children,
  );
}
