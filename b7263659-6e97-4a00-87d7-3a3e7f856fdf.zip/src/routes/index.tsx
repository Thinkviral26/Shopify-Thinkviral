import { createFileRoute } from "@tanstack/react-router";
import { Toaster } from "sonner";

import { CartProvider } from "@/lib/cart";
import { Loader } from "@/components/site/Loader";
import { Navbar } from "@/components/site/Navbar";
import { Hero } from "@/components/site/Hero";
import { TrustStrip } from "@/components/site/TrustStrip";
import { ProductIntro } from "@/components/site/ProductIntro";
import { Marquee } from "@/components/site/Marquee";
import { FeatureGrid } from "@/components/site/FeatureGrid";
import { LifestyleSection } from "@/components/site/LifestyleSection";
import { ProductPurchase } from "@/components/site/ProductPurchase";
import { Reviews } from "@/components/site/Reviews";
import { FAQ } from "@/components/site/FAQ";
import { FinalCTA } from "@/components/site/FinalCTA";
import { Footer } from "@/components/site/Footer";
import { CartDrawer } from "@/components/site/CartDrawer";

const title = "THINKVIRAL — Wireless Earbuds Built for Everyday Life";
const description =
  "THINKVIRAL wireless earbuds: clean, minimal, uncomplicated everyday audio at ₹899. Affordable consumer tech, designed for the everyday.";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <CartProvider>
      <Loader />
      <Navbar />
      <main>
        <Hero />
        <TrustStrip />
        <ProductIntro />
        <Marquee />
        <FeatureGrid />
        <LifestyleSection />
        <ProductPurchase />
        <Reviews />
        <FAQ />
        <FinalCTA />
      </main>
      <Footer />
      <CartDrawer />
      <Toaster
        position="bottom-right"
        toastOptions={{
          className: "label-mono",
          style: {
            background: "oklch(0.145 0 0)",
            color: "oklch(1 0 0)",
            border: "1px solid oklch(1 0 0 / 12%)",
            borderRadius: "0",
          },
        }}
      />
    </CartProvider>
  );
}
