import { createFileRoute, Link } from "@tanstack/react-router";
import { Toaster, toast } from "sonner";
import { ShoppingBag, Sparkles } from "lucide-react";

import { CartProvider, useCart } from "@/lib/cart";
import { product, formatPrice } from "@/data/product";
import { Navbar } from "@/components/site/Navbar";
import { Footer } from "@/components/site/Footer";
import { CartDrawer } from "@/components/site/CartDrawer";
import { Reveal } from "@/components/site/Reveal";

const title = "Shop — THINKVIRAL";
const description =
  "Browse the THINKVIRAL collection. Everyday wireless audio, starting with our TWS earbuds with ANC — more products coming soon.";

export const Route = createFileRoute("/shop")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ShopPage,
});

function ShopPage() {
  return (
    <CartProvider>
      <Navbar />
      <main className="bg-ink text-paper">
        <ShopHero />
        <ProductGrid />
      </main>
      <Footer />
      <CartDrawer />
      <Toaster
        position="bottom-right"
        toastOptions={{
          className: "label-mono",
          style: {
            background: "oklch(0.145 0 0)",
            color: "oklch(1 0 0)",
            border: "1px solid oklch(1 0 0 / 12%)",
            borderRadius: "0",
          },
        }}
      />
    </CartProvider>
  );
}

function ShopHero() {
  return (
    <section className="relative overflow-hidden px-5 pt-36 pb-16 md:px-10 md:pt-44 md:pb-24">
      <div className="grid-texture absolute inset-0 opacity-50" />
      <div
        aria-hidden
        className="absolute -top-40 left-1/2 h-[420px] w-[720px] -translate-x-1/2 rounded-full bg-rgb-blue/15 blur-[140px]"
      />
      <div className="relative mx-auto max-w-[1600px]">
        <Reveal>
          <p className="label-mono text-rgb-blue">The Collection / Shop</p>
        </Reveal>
        <Reveal delay={100}>
          <h1 className="display mt-6 max-w-4xl text-[13vw] leading-[0.95] md:text-[7vw]">
            EVERYTHING
            <br />
            WE MAKE.
          </h1>
        </Reveal>
        <Reveal delay={200}>
          <p className="mt-8 max-w-xl text-base leading-relaxed text-grey md:text-lg">
            A small, honest lineup of everyday tech. One product today — built
            properly. More on the way.
          </p>
        </Reveal>
      </div>
    </section>
  );
}

function ProductGrid() {
  const { add, open } = useCart();

  const handleAdd = () => {
    add({
      name: product.name,
      color: product.colors[0]?.name ?? "Standard",
      price: product.price,
      qty: 1,
      image: product.images[0]?.src ?? "",
    });
    toast.success("Added to bag");
    open();
  };

  return (
    <section className="px-5 pb-20 md:px-10 md:pb-28">
      <div className="mx-auto grid max-w-[1600px] gap-6 md:grid-cols-2 lg:grid-cols-3">
        <Reveal className="md:col-span-2 lg:col-span-1">
          <article className="group glass-dark relative flex h-full flex-col overflow-hidden">
            <div className="relative aspect-square overflow-hidden">
              <img
                src={product.heroImage}
                alt={product.name}
                className="h-full w-full object-contain p-10 transition-transform duration-700 ease-out group-hover:scale-105"
              />
              <span className="label-mono absolute top-4 left-4 bg-rgb-blue px-2.5 py-1 text-[10px] text-paper">
                {product.badge}
              </span>
            </div>
            <div className="flex flex-1 flex-col gap-4 border-t border-white/10 p-6 md:p-8">
              <div>
                <p className="label-mono text-grey">{product.code}</p>
                <h2 className="display mt-2 text-xl md:text-2xl">
                  {product.titleLines.join(" ")}
                </h2>
                <p className="mt-3 text-sm leading-relaxed text-grey">
                  {product.description}
                </p>
              </div>
              <div className="mt-auto flex items-center justify-between gap-4">
                <div className="flex items-baseline gap-3">
                  <span className="text-xl font-semibold">
                    {formatPrice(product.price)}
                  </span>
                  <span className="text-sm text-grey line-through">
                    {formatPrice(product.compareAtPrice)}
                  </span>
                </div>
                <button
                  onClick={handleAdd}
                  className="label-mono flex items-center gap-2 bg-paper px-5 py-3 text-ink transition-colors hover:bg-rgb-blue hover:text-paper"
                >
                  <ShoppingBag className="size-4" strokeWidth={1.5} />
                  Add to bag
                </button>
              </div>
            </div>
          </article>
        </Reveal>

        {[1, 2].map((n) => (
          <Reveal key={n} delay={n * 120}>
            <div className="glass-dark relative flex h-full min-h-[320px] flex-col items-center justify-center gap-4 border-dashed p-8 text-center">
              <Sparkles className="size-6 text-rgb-blue" strokeWidth={1.5} />
              <p className="label-mono text-grey">Slot {String(n).padStart(2, "0")}</p>
              <p className="display text-lg text-paper/80 md:text-xl">
                MORE PRODUCTS
                <br />
                COMING SOON
              </p>
              <p className="max-w-xs text-sm leading-relaxed text-grey">
                We're working on the next everyday essential. Check back soon.
              </p>
            </div>
          </Reveal>
        ))}
      </div>

      <Reveal delay={150}>
        <div className="mx-auto mt-16 flex max-w-[1600px] flex-col items-start justify-between gap-6 border-t border-hairline-dark pt-10 md:flex-row md:items-center">
          <p className="max-w-md text-sm leading-relaxed text-grey">
            Want to see the full story behind our first product?
          </p>
          <Link
            to="/"
            className="label-mono border border-paper/25 px-6 py-3 transition-colors hover:border-paper hover:bg-paper hover:text-ink"
          >
            Back to home
          </Link>
        </div>
      </Reveal>
    </section>
  );
}

